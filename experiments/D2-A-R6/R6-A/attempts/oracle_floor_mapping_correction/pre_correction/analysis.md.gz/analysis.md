# D2-A-R6-A same-scene detector and estimator baseline

**Git SHA:** `c82f18178541c3167e3d9841f304d75a3f08e3f4`  
**Prediction run SHA:** `e3972ae94430abd3d79eae7e1ee9179f68062648`  
**G0:** PASS_WITH_RECORDED_PROTOCOL_ORDER_DEVIATION  
**Final blind:** False  
**Protocol-order deviation:** Before G0 two registered scenes were generated in engineering tests, with only shapes and IDs inspected; no IQ/label values or predictions were inspected or retained. Tests now use independent engineering seeds. See docs/task_alignments/D2-A-R6_alignment.md.

## Detection summary at global Pfa 0.05

| Method | AUC | Verification Pfa | Pfa one-sided 95% upper | Pd | Joint success | Native Doppler RMSE (Hz) |
|---|---:|---:|---:|---:|---:|---:|
| B0 | 0.5307 | 0.0512 | 0.0546 | 0.0527 | 0.0002 | 236.24 |
| B1 | 0.5308 | 0.0511 | 0.0545 | 0.0526 | 0.0002 | 235.91 |
| B2 | 0.5308 | 0.0511 | 0.0545 | 0.0526 | 0.0002 | 235.87 |
| B3 | 0.8656 | 0.0523 | 0.0558 | 0.3594 | 0.3345 | 71.57 |
| R3_T1 | 0.9528 | 0.0508 | 0.0542 | 0.8034 | 0.7806 | 71.57 |
| R3_T2 | 0.9350 | 0.0506 | 0.0540 | 0.7830 | 0.7586 | 119.42 |
| Medium | 0.9830 | 0.0467 | 0.0500 | 0.9334 | 0.8306 | 24.68 |

## Figures

- `experiments/D2-A-R6/R6-A/figures/roc_curves.png`
- `experiments/D2-A-R6/R6-A/figures/pfa_by_condition.png`
- `experiments/D2-A-R6/R6-A/figures/joint_success_by_condition.png`
- `experiments/D2-A-R6/R6-A/figures/doppler_rmse_actual_oracle.png`

## Interpretation limits

- R6-A uses development scenes and does not establish final blind performance.
- R3 T1/T2 remain development candidates without fixed-threshold qualification.
- Oracle-candidate estimates are offline diagnostics and cannot be used as deployable performance.
- Detector and frequency-estimator errors are reported separately; joint success includes detection, range, and Doppler gates.
- Timing records describe this offline evaluation boundary, not full system latency.
